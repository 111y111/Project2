<script>
  
</script>

<section class="header">
  
</section>

<style>
  .header { display:flex; align-items:center; gap:8px; padding:8px 0; }
</style>