<script>
  import ToolForm from '$lib/components/ToolForm.svelte';
</script>

<h1>แบบประเมินยานพาหนะและอุปกรณ์</h1>
<ToolForm />
