<script>
  import FacilitiesForm from '$lib/components/FacilitiesForm.svelte';
</script>

<h1>แบบประเมินสถานที่ต่างๆ</h1>
<FacilitiesForm />