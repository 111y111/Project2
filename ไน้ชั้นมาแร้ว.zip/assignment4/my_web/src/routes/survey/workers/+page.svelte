<script>
  import WorkerForm from '$lib/components/WorkerForm.svelte';
</script>

<h1>แบบประเมินผู้ปฏิบัติงาน</h1>
<WorkerForm />
