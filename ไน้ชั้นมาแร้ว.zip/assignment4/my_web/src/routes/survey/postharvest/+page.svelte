<script>
  import PostharvestForm from '$lib/components/PostharvestForm.svelte';
</script>

<h1>แบบประเมินการพักผลผลิต</h1>
<PostharvestForm />
