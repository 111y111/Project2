<script>
  import FertiliForm from '$lib/components/FertiliForm.svelte';
</script>

<h1>แบบประเมินหมวดการใช้ปุ๋ยและยา</h1>
<FertiliForm />
