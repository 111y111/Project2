<script>
  import SoilForm from '$lib/components/SoilForm.svelte';
</script>

<h1>แบบประเมินการจัดการที่ดิน</h1>
<SoilForm />
