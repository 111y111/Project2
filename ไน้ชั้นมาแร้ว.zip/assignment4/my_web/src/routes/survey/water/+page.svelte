<script>
  import WaterForm from '$lib/components/WaterForm.svelte';
</script>

<h1>แบบประเมินการจัดการน้ำ</h1>
<WaterForm />
