<script>
  import HarvestForm from '$lib/components/HarvestForm.svelte';
</script>

<h1>แบบประเมินการเก็บเกี่ยว</h1>
<HarvestForm />
