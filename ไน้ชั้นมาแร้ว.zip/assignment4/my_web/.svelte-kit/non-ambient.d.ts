
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/" | "/survey" | "/survey/facilities" | "/survey/fert-chem" | "/survey/postharvest" | "/survey/soil" | "/survey/tools" | "/survey/water" | "/survey/workers" | "/survey/้harvest";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/survey": Record<string, never>;
			"/survey/facilities": Record<string, never>;
			"/survey/fert-chem": Record<string, never>;
			"/survey/postharvest": Record<string, never>;
			"/survey/soil": Record<string, never>;
			"/survey/tools": Record<string, never>;
			"/survey/water": Record<string, never>;
			"/survey/workers": Record<string, never>;
			"/survey/้harvest": Record<string, never>
		};
		Pathname(): "/" | "/survey" | "/survey/" | "/survey/facilities" | "/survey/facilities/" | "/survey/fert-chem" | "/survey/fert-chem/" | "/survey/postharvest" | "/survey/postharvest/" | "/survey/soil" | "/survey/soil/" | "/survey/tools" | "/survey/tools/" | "/survey/water" | "/survey/water/" | "/survey/workers" | "/survey/workers/" | "/survey/้harvest" | "/survey/้harvest/";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/robots.txt" | string & {};
	}
}