import * as universal from "../../../../src/routes/survey/[slug]/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/survey/[slug]/+page.svelte";