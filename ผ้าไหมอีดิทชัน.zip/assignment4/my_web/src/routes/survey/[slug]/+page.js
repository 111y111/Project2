import { mapping } from '$lib/SurveyQuestion';

export function load({ params }) {
  const slug = params.slug;
  const { title, questions } = mapping[slug];

  return { slug, title, questions };
}