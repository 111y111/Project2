<script>
  export let data;
  const { slug, title, questions } = data;

  let answers = {};
  let filePreviews = {};
  let extraAnswer = ''; // เฉพาะหมวด fertilization id=1

  // ตั้งค่าเริ่มต้น
  questions.forEach(q => (answers[q.id] = ''));

  function handleFileChange(event, id) {
    const file = event.target.files?.[0];
    if (!file) return;
    answers[id] = file;
    filePreviews[id] = URL.createObjectURL(file);
  }

  function submitForm() {
    const payload = { slug, title, answers, extraAnswer };
    console.log('✅ ส่งข้อมูล:', payload);
    alert(`ส่งแบบประเมินหมวด "${title}" เรียบร้อย`);
  }
</script>

<h2>{title}</h2>

<form on:submit|preventDefault={submitForm}>
  {#each questions as q}
    <div class="question-block">
      <label>{q.text}</label>
  

      <!-- 🧩 เงื่อนไขพิเศษเฉพาะหมวด fertilization -->
      {#if slug === 'fertilization' && q.id === 1}
        {#each q.values as val}
          <label>
            <input type="radio" name="fertilization-q1" value={val} bind:group={answers[q.id]} />
            {val}
          </label>
        {/each}

        {#if answers[q.id] === 'ใช้'}
          <div class="extra-box">
            <label>โปรดระบุรูปแบบการใช้:</label>
            <select bind:value={extraAnswer}>
            <option value="">-- โปรดเลือก --</option>
            <option value="ใช้โดยตรงไม่ผ่านการหมัก">ใช้โดยตรงไม่ผ่านการหมัก</option>
            <option value="ใช้หลังผ่านการหมัก">ใช้หลังผ่านการหมัก</option>
            </select>
          </div>
        {/if}


      {:else if q.type === 'radio'}
        {#each q.values as val}
          <label>
            <input type="radio" name={"q-" + q.id} value={val} bind:group={answers[q.id]} />
            {val}
          </label>
        {/each}

      {:else if q.type === 'select'}
        <select bind:value={answers[q.id]}>
          {#each q.values as option}
            <option value={option}>{option}</option>
          {/each}
        </select>

      {:else if q.type === 'file'}
        <input type="file" on:change={(e) => handleFileChange(e, q.id)} />
        {#if filePreviews[q.id]}
          <img src={filePreviews[q.id]} width="200" />
        {/if}

      {:else}
        <input type="text" bind:value={answers[q.id]} />
      {/if}
    </div>
  {/each}

  <button type="submit">ส่งแบบประเมิน</button>
</form>

<style>
  .question-block {
    margin-bottom: 1rem;
    padding: 0.75rem;
    border: 1px solid #ddd;
    border-radius: 8px;
  }

  .extra-box {
    margin-top: 0.5rem;
    padding: 0.5rem;
    background: #f9fafb;
    border-left: 3px solid #4ade80;
    border-radius: 4px;
  }
</style>
