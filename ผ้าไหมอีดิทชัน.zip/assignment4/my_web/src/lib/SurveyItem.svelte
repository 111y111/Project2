<script>
  /** @type {{
    slug: string,
    title: string,
    lastUpdated?: string,
    note?: string,
    ctaLabel?: string,
    imageAlt?: string
  }} */
  let { slug, title, lastUpdated = '', note = '', ctaLabel = 'ดูรายละเอียด', imageAlt = '' } = $props()
</script>

<div class="card">
  <div class="item">
    <div class="thumb" aria-label={imageAlt}></div>
    <div class="content">
      <h3>{title}</h3>
      {#if lastUpdated}
        <p class="meta">บันทึกข้อมูลล่าสุด {lastUpdated}</p>
      {:else}
        <p class="meta">ยังไม่เคยบันทึกข้อมูล</p>
      {/if}
      
      {#if note}
        <p class="note">{note}</p>
      {/if}
      <a class="btn" href={`/survey/${slug}`}>{ctaLabel}</a>
    </div>
  </div>
</div>

<style>
  .card {
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 14px;
    box-shadow: 0 1px 2px rgba(0,0,0,.04);
  }
  .item {
    display: grid;
    grid-template-columns: 112px 1fr;
    gap: 14px;
    align-items: center;
  }
  .thumb { width: 112px; height: 84px; border-radius: 12px; background: #f3f4f6; border: 1px solid #e5e7eb; }
  .content h3 { margin: 0 0 4px; font-size: 18px; }
  .meta { margin: 0 0 6px; color: #6b7280; font-size: 13px; }
  .note { margin: 0 0 10px; color: #374151; font-size: 14px; }
  .btn { display: inline-block; padding: 8px 12px; border-radius: 10px; text-decoration: none; font-weight: 600; font-size: 14px; }

  .dot { display:inline-block; width:10px; height:10px; border-radius:50%; vertical-align:middle; }
</style>